#include <iostream>
#include <vector>
#include <time.h>

using namespace std;

/* Implement: Include header file(s) */
#include "Player.h"
#include "Fill.h"
/* Implement: Control FPS if you need */

clock_t start = clock();
clock_t endtime;

#define WIDTH 300		// window's width
#define HEIGHT 400		// window's height

int sp_key;				// special key

vector<Fill> Fl;
vector<Fill> boundary;
vector<int> key;
vector<Fill> boundary_update;
vector<int> key_update;


Player pl(WIDTH /2 ,(HEIGHT-100)/2, 1, 1, 0, 6);
int inFill = 0;
int inFill_past = 0;
Fill temp(WIDTH / 2, (HEIGHT - 100) / 2);


void init() {
	int initial_box = 10;
	
	for (int i = -initial_box; i < initial_box; i++) {
		for (int j = -initial_box; j < initial_box; j++) {
			temp.setPos(WIDTH / 2 + i, (HEIGHT - 100) / 2 + j);
			Fl.push_back(temp);
			if (i == -initial_box || i == initial_box - 1 || j == -initial_box || j == initial_box - 1)
				boundary.push_back(temp);
		}
	}
	
	pl.setPos(WIDTH / 2, (HEIGHT - 100) / 2);
	sp_key = 0;
	inFill = 0;
	inFill_past = 0;


}
int Flagging() {
	for (unsigned int i = 0; i < boundary.size()-1; i++) {
		if (boundary[i].getX() == pl.getX() && boundary[i].getY() == pl.getY())
			return 1;
	}
	return 0;
}



void restart() {

	

	init();

}
/*
void Floodfill(vector<Fill> v, vector<int> k) {
	vector<Fill> boundary_update;
	vector<int> key_update;
	int onoff_up, onoff_down, onoff_left, onoff_right;
	if (v.size() != 0) {
		for (unsigned int i = 0; i < v.size(); i++) {
			onoff_up = 1;
			onoff_down = 1;
			onoff_left = 1;
			onoff_right = 1;

			if (k[i] == 1) {
				for (unsigned int j = 0; j < Fl.size(); j++) {
					if (Fl[j].getX() == v[i].getX() + 1 && Fl[j].getY() == v[i].getY()) {
						onoff_up = 0;
						break;
					}
				}
				if (onoff_up == 1) {
					temp.setPos(v[i].getX() + 1, v[i].getY());
					boundary_update.push_back(temp);
					key_update.push_back(k[i]);
					Fl.push_back(temp);
				}
			}
			if (k[i] == 2) {
				for (unsigned int j = 0; j < Fl.size(); j++) {
					if (Fl[j].getX() == v[i].getX() - 1 && Fl[j].getY() == v[i].getY()) {
						onoff_down = 0;
						break;
					}
				}
				if (onoff_down == 1) {
					temp.setPos(v[i].getX() - 1, v[i].getY());
					boundary_update.push_back(temp);
					key_update.push_back(k[i]);
					Fl.push_back(temp);
				}
			}
			if (k[i] == 3) {
				for (unsigned int j = 0; j < Fl.size(); j++) {
					if (Fl[j].getX() == v[i].getX() && Fl[j].getY() == v[i].getY() + 1) {
						onoff_left = 0;
						break;
					}
				}
				if (onoff_left == 1) {
					temp.setPos(v[i].getX(), v[i].getY() + 1);
					boundary_update.push_back(temp);
					key_update.push_back(k[i]);
					Fl.push_back(temp);
				}
			}
			if (k[i] == 4){
				for (unsigned int j = 0; j < Fl.size(); j++) {

					if (Fl[j].getX() == v[i].getX() && Fl[j].getY() == v[i].getY() - 1) {
						onoff_right = 0;
						break;
					}
				}
				if (onoff_right == 1) {
					temp.setPos(v[i].getX(), v[i].getY() - 1);
					boundary_update.push_back(temp);
					key_update.push_back(k[i]);
					Fl.push_back(temp);
				}
				
			}
		

		}
		cout << boundary_update.size() << endl;
		//Floodfill(boundary_update, key_update);
	}
}
*/
void add_boundary() {
	if (inFill == 1 && inFill_past == 0) {
		inFill_past = 1;
		cout << "what" << endl;
	}
	
	else if (inFill == 0 && inFill_past ==1 ) {

		temp.setPos(pl.getX(), pl.getY());
		boundary_update.push_back(temp);
		//for (unsigned int i = 0; i < boundary.size()-1; i++) {
		//	if (boundary[i].getX() == pl.getX() && boundary[i].getY() == pl.getY())
		//		restart();
		//}
	}
	
	else if (inFill == 1 && inFill_past == 1) {
		inFill_past = 0;
		for (unsigned int i = 0; i < boundary_update.size(); i++) {
			boundary.push_back(boundary_update[i]);
		}
		boundary_update.clear();
	}
	
	cout << inFill << inFill_past << endl;
	cout << boundary.size() << endl;
}

void processSpecialKeys(int key, int x, int y) {
	/* Implement: Set key input */

	switch (key) {
	case GLUT_KEY_UP:
		if(sp_key != 2)
			sp_key = 1;
		break;
	case GLUT_KEY_DOWN:
		if (sp_key != 1)
			sp_key = 2;
		break;
	case GLUT_KEY_LEFT:
		if (sp_key != 4)
			sp_key = 3;
		break;
	case GLUT_KEY_RIGHT:
		if (sp_key != 3)
			sp_key = 4;
		break;

	}
}
/*

*/
void idle() {
	/* Implement: Move the square */
	endtime = clock();
	if (endtime - start > 1000 / 30) {
		pl.move(sp_key,int(WIDTH),int(HEIGHT)-100);
		inFill = Flagging();
		add_boundary();


		start = endtime;
	}
	glutPostRedisplay();
}
//void idle() {
//	/* Implement: Move the square */
//	pl.move(sp_key, int(WIDTH), int(HEIGHT) - 100);
//	inFill = Flagging();
//	add_boundary();
//
//
//	glutPostRedisplay();
//}

void renderScene() {
	// Clear Color and Depth Buffers
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0, WIDTH, 0, HEIGHT);
	for (unsigned int i = 0; i < Fl.size(); i++) {
		Fl[i].draw();
	}
	for (unsigned int i = 0; i < boundary.size(); i++) {
		boundary[i].draw();
	}
	for (unsigned int i = 0; i < boundary_update.size(); i++) {
		if(i%4 == 0 || i%4 ==1)
			boundary_update[i].draw();
	}
	pl.draw();

	glutSwapBuffers();
}

void main(int argc, char **argv) {
	// init GLUT and create Window
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(300, 0);
	glutInitWindowSize(WIDTH, HEIGHT);

	glutCreateWindow("Drawing Square & Equilateral Triangle");


	init();
	// register callbacks
	glutDisplayFunc(renderScene);
	glutSpecialFunc(processSpecialKeys);
	glutIdleFunc(idle);

	// enter GLUT event processing cycle
	glutMainLoop();

}
