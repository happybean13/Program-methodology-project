#pragma once
#include <GL/glut.h>
#include "Square.h"

class Fill : public Square {
public:
	Fill(float x, float y);
	~Fill();
	virtual void draw() const;


};