#pragma once

/* Implement: Define Quad class */

#include <GL/glut.h>
#include "Color.h"
#include "Quad.h"

class Square : public Quad, public Color {

public:
	Square(float x, float y, float r, float g, float b, float sl);
	~Square();
	virtual void draw() const;
	float getSideLength() const;
protected:
	float  side_length;
};